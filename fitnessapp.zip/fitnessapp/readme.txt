-> Database Name: gymsysdb

-> Admin Login Details

Username: admin
Password: password